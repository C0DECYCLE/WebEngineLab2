# METIS

This version was adapted from [Nanite WebGPU](https://github.com/Scthe/nanite-webgpu) by [Marcin Matuszczyk](https://github.com/Scthe). Redistributed under [MIT license](https://github.com/Scthe/nanite-webgpu/blob/master/LICENSE).

The [Emscripten version of METIS](https://github.com/AIFanatic/three-nanite/tree/master/src/metis-5.2.1) was compiled by GitHub user [AIFanatic](https://github.com/AIFanatic). Redistributed under [MIT license](https://github.com/AIFanatic/three-nanite/blob/master/LICENSE).
